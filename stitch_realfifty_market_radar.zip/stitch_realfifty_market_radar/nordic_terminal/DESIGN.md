---
name: Nordic Terminal
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393f'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e1e9'
  on-surface-variant: '#c1c7d4'
  inverse-surface: '#e3e1e9'
  inverse-on-surface: '#2f3036'
  outline: '#8b919d'
  outline-variant: '#414752'
  surface-tint: '#a4c9ff'
  primary: '#a4c9ff'
  on-primary: '#00315d'
  primary-container: '#0d74ce'
  on-primary-container: '#f9f9ff'
  inverse-primary: '#005fad'
  secondary: '#4cd6fb'
  on-secondary: '#003642'
  secondary-container: '#00b2d6'
  on-secondary-container: '#003f4e'
  tertiary: '#ffb3af'
  on-tertiary: '#68000e'
  tertiary-container: '#ca4344'
  on-tertiary-container: '#fff8f7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d4e3ff'
  primary-fixed-dim: '#a4c9ff'
  on-primary-fixed: '#001c39'
  on-primary-fixed-variant: '#004884'
  secondary-fixed: '#b3ebff'
  secondary-fixed-dim: '#4cd6fb'
  on-secondary-fixed: '#001f27'
  on-secondary-fixed-variant: '#004e5f'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3af'
  on-tertiary-fixed: '#410005'
  on-tertiary-fixed-variant: '#8d141e'
  background: '#121318'
  on-background: '#e3e1e9'
  surface-variant: '#34343a'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.75rem
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 1.75rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: 1.5rem
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1rem
    letterSpacing: '0'
  metric-display:
    fontFamily: JetBrains Mono
    fontSize: 1.875rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.04em
  metric-lg:
    fontFamily: JetBrains Mono
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: 1.5rem
    letterSpacing: -0.03em
  metric-md:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.125rem
    letterSpacing: -0.02em
  metric-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 0.875rem
    letterSpacing: -0.01em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 0.625rem
    fontWeight: '500'
    lineHeight: 0.75rem
    letterSpacing: 0.08em
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  terminal-header-h: 2.5rem
  terminal-ticker-h: 1.75rem
  grid-gutter: 1px
  panel-padding-tight: 0.5rem
  panel-padding-dense: 0.75rem
  panel-padding-comfort: 1rem
---

## Brand & Style

This design system establishes a high-density, authoritative institutional terminal for macro and micro real estate analytics. It converges the precision of financial market terminals with the restraint, clarity, and typographic discipline of contemporary Scandinavian editorial design. 

The aesthetic is functional, uncompromising, and analytical. It rejects decorative gradients, illustrative fluff, and trivial emojis in favor of razor-sharp geometries, systematic structural lines, and dense, tabular metrics. The visual hierarchy communicates institutional gravity: deep carbon foundations, surgical high-contrast data planes, and disciplined kinetic status indicators. 

The user experience evokes the focus of an algorithmic trading desk operating on real-world illiquid assets: calm under volatility, instant in spatial-financial pattern recognition, and unyielding in data integrity.

## Colors

The palette operates with strict semantic discipline, anchored by a deep obsidian core (`#090A0F`) paired with surgical light tiers and deliberate signal wavelengths.

### Surface System
- **Void Base (`bg-surface-0`):** `#090A0F` — The foundational backdrop for high-frequency analytical dashboards.
- **Surface Elevation 1 (`bg-surface-1`):** `#111319` — Structural cell containers, viewport splits, and pinned sidebars.
- **Surface Elevation 2 (`bg-surface-2`):** `#181B24` — Secondary interactive modules, active table rows, and popovers.
- **Surface Elevation 3 (`bg-surface-3`):** `#222634` — Input fills, toggles, and inactive chip states.
- **Contrast Light Surface (`bg-light`):** `#F8F9FA` — Reserved for dedicated high-contrast export views, institutional tear-sheets, and inverted breakout sheets. Pure white (`#FFFFFF`) serves as the peak luminance accent.

### Neutral Monochrome Tier
- **Text High-Contrast:** `#FFFFFF` — Primary tickers, critical metrics, and macro indicators.
- **Text Moderate:** `#94A3B8` — Table column keys, secondary values, timestamps, and axis values.
- **Text Muted:** `#475569` — Metadata, inactive parameters, and terminal watermarks.
- **Border Structural:** `#1E2330` — Default hairline dividers (1px pure geometric separation).
- **Border Active:** `#334155` — Hovered borders, active focus rings, and pinned crosshairs.

### Metric Signal Wavelengths
- **Terminal Blue / Metric Primary:** `#0D74CE` — Core analytical signals, current active market selections, and transactional depth.
- **Institutional Cyan:** `#00B4D8` — Capital inflows, liquidity yield overlays, and positive price momentum.
- **Financial Crimson:** `#E05353` — Volatility divergence, downside delta, supply overhang, and default hazards.
- **Market Amber:** `#F59E0B` — Regulatory intervention alerts, illiquid transaction warnings, and policy review boundaries.

## Typography

The typographic system pairs the cold, geometric neutrality of **Inter** with the computational rigor of **JetBrains Mono**.

- **Inter** handles narrative structure, municipal nomenclature, asset classification, and interface navigation. Letter spacing is compressed slightly on larger weights to mirror publication-grade financial print sheets.
- **JetBrains Mono** governs all quantitative data, financial metrics, coordinates, delta variations, and orderbook statistics. Tabular figures (`tnum`) and slashed zeros must be permanently enabled across all metric instances to preserve strict columnar vertical alignment across real-time price updates.
- All section indicators, operational states, and structural table headers require `label-caps` rendered in forced uppercase with expanded letter-spacing (`0.08em`) to anchor horizontal scan lines.

## Layout & Spacing

The layout model is driven by a split-pane, high-density modular grid, reminiscent of professional institutional trading workstations.

### Structural Philosophy
- **Hairline Grid System:** Panes do not float. They lock flush against adjacent modules separated by `1px` structural borders (`#1E2330`). Empty margins are eliminated within primary analytical screens; whitespace is confined inside cell boundaries to preserve information density.
- **Vertical Hierarchy:**
  1. Global Command & Status Strip (`terminal-header-h`: 40px)
  2. Seoul Macro Yield & Transaction Ticker (`terminal-ticker-h`: 28px)
  3. Master-Detail Workstation (Dynamic Viewport: Map Engine + Tabular Ledger + Orderbook Depth)
  4. Query & Filter Dock / Telemetry Drawer (Fixed bottom or collapsed side dock)

### Breakpoints & Adaptive Reflow
- **Desktop (≥ 1440px):** Multi-pane split view (3 to 4 concurrent operational panels). Zero window scrolling required for the core dashboard; nested panels manage internal overflows via custom hairline scrollbars.
- **Compact Desktop / Tablet Landscape (1024px – 1439px):** 2-column workstation. Geospatial radar and quantitative ledger share split screens (55% / 45%); secondary telemetry moves to collapsible utility sheets.
- **Mobile / Phone (< 1024px):** Single-column stacked mode. The geospatial map anchors the top viewport (40vh) with metric panels snapping underneath in sticky tabbed sheets. Data density shifts from horizontal tabular comparison to vertical micro-cards.

## Elevation & Depth

This design system deliberately rejects heavy diffusion drop-shadows, skeuomorphic bevels, and atmospheric blurs. Depth is communicated strictly through planar color theory, luminance offsets, and geometric edge contrasts.

### Layer Architecture
1. **Baseplate (`#090A0F`):** Deepest visual plane. Anchors the overarching software shell, system trays, and unpopulated canvas regions.
2. **Structural Tiles (`#111319`):** Primary data containers, charts, and map controls. Separated exclusively by a `1px` border of `#1E2330`.
3. **Elevated Drawers & Flyouts (`#181B24`):** Command palettes, multi-tier metric filters, and asset detail inspect sheets. Instead of fuzzy shadows, use a `1px` outline of `#334155` complemented by a sharp, directional occlusion edge: `0 4px 0 0 rgba(0, 0, 0, 0.6)`.
4. **Modal / Critical Dialog Tier (`#111319`):** Centered dialogs render over a darkened, desaturated backdrop curtain (`rgba(5, 6, 9, 0.85)`). The modal perimeter is bound by a dual-line stroke: an inner 1px `#1E2330` and an outer hairline highlight `#334155`.

## Shapes

The shape system is strictly architectural and uncompromising: **Level 0 (Sharp)**.

- All UI components—including buttons, input fields, tooltips, data cells, charts, and modal frames—feature strict right angles (`border-radius: 0px`).
- In rare micro-element scenarios where human touch ergonomics require a visual signal (such as circular map pin beacons or pulsing telemetry dots), elements adopt full primitive geometry (`border-radius: 9999px`), maintaining an intentional contrast between pure rectilinear machinery and absolute geometric circles.

## Components

### 1. Buttons & Terminal Triggers
- **Primary Action:** Solid background (`#0D74CE`), text `#FFFFFF` (`JetBrains Mono`, 11px, Medium, uppercase). Sharp edges. No shadow. Active state: `#0A5CA5`. Focus state: 1px offset ring in `#00B4D8`.
- **Secondary / Ghost:** Transparent fill, 1px perimeter of `#1E2330`, text `#94A3B8`. Hover: `#181B24`, text `#FFFFFF`, border `#334155`.
- **Destructive / Short:** Background transparent, 1px border `#E05353`, text `#E05353`. Hover: background `rgba(224, 83, 83, 0.1)`.
- **Trigger Height:** Hard-coded heights of 24px (Micro), 32px (Default), and 40px (Command Bar).

### 2. Input Fields & Parameter Steppers
- Background: `#111319`. Border: 1px solid `#1E2330`. Typography: `JetBrains Mono` 12px.
- Focus: Border shifts instantly to `#0D74CE`. No glow or blurred outline.
- Label: Positioned directly in the top-left boundary corner using `label-caps` in `#475569`.
- Affixes: Monospaced units (`KRW/py`, `m²`, `%`, `bps`) fixed to the right edge in `#475569`.

### 3. Data Tables & High-Density Ledgers
- Table headers: Height 24px, background `#111319`, border-bottom 1px solid `#1E2330`, text `label-caps` in `#475569`.
- Table rows: Height 28px (ultra-dense) or 36px (standard). Alternating rows: none. Hover row background: `#181B24`.
- Numeric alignment: Always right-aligned with tabular figures. Negative values formatted with leading financial minus (`−`) in `#E05353`; positive deltas in `#00B4D8` with `+`.
- Zero-state and loading: Skeletal wireframes using static `#181B24` structural rectangles; no shimmering or organic pulses.

### 4. Chips, Status Tags & Regime Pills
- Geometry: Pure rectangular tags (0px radius). Height 18px or 22px.
- Construction: Semi-translucent background (`rgba(x, y, z, 0.08)`) with a matching 1px hairline border.
- Vector Indicator: Preceded by a 4px solid square icon indicating state:
  - Bullish / Flow Inflow: Square `#00B4D8`
  - Hazard / Overhang: Square `#E05353`
  - Stagnant / Baseline: Square `#475569`

### 5. Selection Controls (Checkboxes & Radios)
- Checkboxes: 12px × 12px square. Border 1px `#334155`. Checked state: Background `#0D74CE` with an inner 4px white dot (no curved checks).
- Radio buttons: 12px × 12px diamond (45-degree rotated square). Border 1px `#334155`. Selected: Core diamond `#00B4D8`.

### 6. Cards & Metric Bricks
- Container: Surface `#111319`, outline 1px `#1E2330`.
- Metric Header: Top border includes a 2px accent indicator running the full width (Cyan for pricing, Crimson for debt ratio, Slate for inventory).
- Value Display: Large monospaced numeric value anchored to the bottom-left, secondary baseline comparison metric right-aligned in muted mono text.

### 7. Custom PropTech Terminal Components
- **District Depth Heat Bar:** A sub-component for apartment complex valuation showing transaction clusters. A 4px-high horizontal distribution rail plotting historical trades across price quartiles with 1px tick marks.
- **Jeonse-to-Price Ratio Crosshair:** A dual-axis micro-indicator showing gap investment compression risk.
- **Municipal Regulatory Tag:** High-contrast indicator (`#F8F9FA` text on `#1E2330` background) displaying current speculative zone status (e.g., `SPECULATIVE_OVERHEATED_ZONE_LTV_40`).